// File removed: moved to hooks/useFormValidation.js
